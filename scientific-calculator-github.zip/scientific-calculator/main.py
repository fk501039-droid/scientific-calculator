"""A simple command-line scientific calculator."""
import math

def calculate():
    print("\n=== Scientific Calculator ===")
    print("Operations: +  -  *  /  **  sqrt  sin  cos  tan  log  ln")
    print("Angles for sin/cos/tan are entered in degrees.")
    print("Type 'q' to quit.\n")

    while True:
        op = input("Operation: ").strip().lower()
        if op in {"q", "quit", "exit"}:
            print("Goodbye!")
            break

        try:
            if op in {"+", "-", "*", "/", "**"}:
                a = float(input("First number: "))
                b = float(input("Second number: "))
                if op == "+":
                    result = a + b
                elif op == "-":
                    result = a - b
                elif op == "*":
                    result = a * b
                elif op == "/":
                    result = a / b
                else:
                    result = a ** b

            elif op == "sqrt":
                result = math.sqrt(float(input("Number: ")))
            elif op in {"sin", "cos", "tan"}:
                degrees = float(input("Angle in degrees: "))
                radians = math.radians(degrees)
                result = getattr(math, op)(radians)
            elif op == "log":
                result = math.log10(float(input("Positive number: ")))
            elif op == "ln":
                result = math.log(float(input("Positive number: ")))
            else:
                print("Unknown operation. Try again.")
                continue

            print(f"Result: {result:.10g}\n")
        except ZeroDivisionError:
            print("Error: division by zero is not allowed.\n")
        except ValueError:
            print("Error: enter a valid number (and use positive values for logs/square roots).\n")
        except OverflowError:
            print("Error: result is too large.\n")

if __name__ == "__main__":
    calculate()
